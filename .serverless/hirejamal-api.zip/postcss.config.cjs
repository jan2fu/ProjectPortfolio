module.exports = {
  // Path to your Tailwind CSS file
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
